===  Plugin Name ===  
Contributors: thimpress, tunnhn  
Donate link:  
Tags: lms, elearning, e-learning, learning management system, education, course, courses, quiz, quizzes, questions, training, guru, sell courses  
Requires at least: 3.8  
Tested up to: 4.2.2  
Stable tag: trunk  
License: GPLv2 or later  
License URI: http://www.gnu.org/licenses/gpl-2.0.html  

LearnPress Woo Payment is an extension plugin to integrate Woocommerce to LearnPress as a payment solution.  

== Description ==  
LearnPress Woo Payment is an extension plugin to integrate Woocommerce to LearnPress as a payment solution.  

== Installation ==

**From your WordPress dashboard**  
1. Visit 'Plugin > Add new'.  
2. Search for 'LearnPress Woo Payment'.  
3. Activate LearnPress from your Plugins page.  

**From WordPress.org**  
1. Search, select and download LearnPress Woo Payment.    
2. Activate the plugin through the 'Plugins' menu in WordPress Dashboard.  

== Frequently Asked Questions ==  

Check out <a href="http://docs.thimpress.com/learnpress" target="_blank">LearnPress</a> sites.  

== Screenshots ==  
1. Plugin frontend    

== Changelog ==

= 1.0.1 =
+ Fixed error if WooCommerce is not installed

= 1.0 =
- Compatible with LearnPress 1.0.

= 0.9.1 =  
The first beta release.

== Upgrade Notice ==  
Later :)

== Other note ==  
<a href="http://docs.thimpress.com/learnpress" target="_blank">Documentation</a> is available in ThimPress site.  
<a href="https://github.com/LearnPress/LearnPress/" target="_blank">LearnPress github repo.</a>  